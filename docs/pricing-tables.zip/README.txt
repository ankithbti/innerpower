A Pen created at CodePen.io. You can find this one at http://codepen.io/j-w-v/pen/DIcJx.

 Simple pricing tables. Playing around learning jQuery